--data.lua

require("prototypes.category")
require("prototypes.technology")
require("prototypes.squid-plates")
require("prototypes.squid-furnace")
require("prototypes.squid-processing")
require("prototypes.InkedFloor")